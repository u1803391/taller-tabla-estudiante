/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tabla_estudiantes;

/**
 *
 * @author crist
 */
public class Tabla_estudiantes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        vista vista=new vista();
        vista.setVisible(true);
    }
    
}
